package bankaccount;

import java.util.Scanner;


public class BankAccount {

    // private String Name;
    // private int ID;
    
    // public BankAccount (String Name, int ID){
    //     this.Name = Name;
    //     this.ID = ID;
    // }
    
    // protected String getName(){
    //     return Name;
    // }
    
    // protected int getID(){
    //     return ID;
    // }
    
    
    public static void main(String[] args) {
        String name,ask_loan;
        int phone,pin;
        float balance;
        int choice,ch;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("######################################################");
        System.out.println("\nWELCOME TO MEEZAN, THE PREMIER ISLAMIC BANK");
        System.out.println("\n######################################################");
        System.out.println("To create your account:\nEnter your name:");
        name = sc.nextLine();
        System.out.println("Enter your desired Account Pin-code:");
        pin = Integer.parseInt(sc.nextLine());
        System.out.println("Enter your phone No:");
        phone = Integer.parseInt(sc.nextLine());
        
        Account acc1 = new Account(name, pin);
        acc1.types();

        // Loan obj = new Loan(name,pin);
        // obj.loan_types();
        
        }
    
        
    }
    

   
    

